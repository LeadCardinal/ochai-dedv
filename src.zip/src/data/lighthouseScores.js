
export const lighthouseScores = [
  {
    id: 'bonsai',
    name: 'reallivebonsai.us',
    url: 'https://reallivebonsai.us',
    performance: 100,
    accessibility: 100,
    bestPractices: 100,
    seo: 100,
    color: 'emerald'
  },
  {
    id: 'meanings',
    name: 'themeaningsoflife.com',
    url: 'https://themeaningsoflife.com',
    performance: 98,
    accessibility: 100,
    bestPractices: 96,
    seo: 100,
    color: 'purple'
  },
  {
    id: 'hsvdrone',
    name: 'hsvdrone.com',
    url: 'https://hsvdrone.com',
    performance: 100,
    accessibility: 100,
    bestPractices: 96,
    seo: 91,
    color: 'blue'
  },
  {
    id: 'ochai',
    name: 'ochai.dev',
    url: 'https://ochai.dev',
    performance: 98,
    accessibility: 96,
    bestPractices: 100,
    seo: 92,
    color: 'cyan'
  }
];
